<?php
// ===============================
// File: db.php
// ===============================
$host = 'localhost';
$user = 'edueyeco_flutter_quiz';
$pass = 'b-F2skeekg]9';
$db   = 'edueyeco_flutter_quiz';

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
