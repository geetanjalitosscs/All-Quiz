<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$host = 'localhost';
$user = 'edueyeco_flutter_quiz';
$pass = 'b-F2skeekg]9';
$db   = 'edueyeco_flutter_quiz';

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("❌ Database connection failed: " . $conn->connect_error);
}
echo "✅ Database connection successful!";
?>
